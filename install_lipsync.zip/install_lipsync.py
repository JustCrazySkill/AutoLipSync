"""
╔══════════════════════════════════════════════════════════════╗
║          AUTO LIPSYNC v5.0 — INSTALLER                      ║
║          Installs all required dependencies                  ║
╚══════════════════════════════════════════════════════════════╝

Usage:
  python install_lipsync.py

Requirements:
  Python 3.9+ must already be installed.
"""

import sys
import os
import subprocess
import platform
import shutil
import urllib.request
import time

# ─────────────────────────────────────────────────────────────
# COLORS (Windows CMD / Unix terminal)
# ─────────────────────────────────────────────────────────────
if sys.platform == "win32":
    os.system("color")  # enable ANSI on Windows

C_RESET  = "\033[0m"
C_BOLD   = "\033[1m"
C_CYAN   = "\033[96m"
C_GREEN  = "\033[92m"
C_YELLOW = "\033[93m"
C_RED    = "\033[91m"
C_DIM    = "\033[2m"
C_BLUE   = "\033[94m"

def ok(msg):    print(f"  {C_GREEN}✔  {msg}{C_RESET}")
def info(msg):  print(f"  {C_CYAN}►  {msg}{C_RESET}")
def warn(msg):  print(f"  {C_YELLOW}⚠  {msg}{C_RESET}")
def err(msg):   print(f"  {C_RED}✘  {msg}{C_RESET}")
def dim(msg):   print(f"{C_DIM}     {msg}{C_RESET}")
def sep():      print(f"\n{C_DIM}{'─' * 62}{C_RESET}\n")
def head(msg):  print(f"\n{C_BOLD}{C_CYAN}  {msg}{C_RESET}")

# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────
def run_pip(*args, upgrade=False):
    """Run pip install with given args."""
    cmd = [sys.executable, "-m", "pip", "install", "--quiet"]
    if upgrade:
        cmd.append("--upgrade")
    cmd.extend(args)
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode == 0, result.stdout + result.stderr

def check_import(module):
    """Check if a Python module can be imported."""
    result = subprocess.run(
        [sys.executable, "-c", f"import {module}; print({module}.__version__ if hasattr({module}, '__version__') else 'ok')"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        return True, result.stdout.strip()
    return False, ""

def ffmpeg_found():
    return shutil.which("ffmpeg") is not None

def cuda_available():
    try:
        result = subprocess.run(
            [sys.executable, "-c", "import torch; print(torch.cuda.is_available())"],
            capture_output=True, text=True, timeout=30
        )
        return result.stdout.strip() == "True"
    except Exception:
        return False

# ─────────────────────────────────────────────────────────────
# BANNER
# ─────────────────────────────────────────────────────────────
def print_banner():
    print(f"""
{C_BOLD}{C_CYAN}
  ╔══════════════════════════════════════════════════════════╗
  ║                                                          ║
  ║       AUTO LIPSYNC v5.0  —  DEPENDENCY INSTALLER        ║
  ║       WhisperX · PyTorch · Librosa · NumPy              ║
  ║                                                          ║
  ╚══════════════════════════════════════════════════════════╝
{C_RESET}""")


# ─────────────────────────────────────────────────────────────
# STEP 1 — CHECK PYTHON
# ─────────────────────────────────────────────────────────────
def step_check_python():
    head("STEP 1 / 7  — Checking Python version")
    sep()
    v = sys.version_info
    info(f"Python version : {v.major}.{v.minor}.{v.micro}")
    info(f"Executable     : {sys.executable}")
    info(f"Platform       : {platform.platform()}")

    if v.major < 3 or (v.major == 3 and v.minor < 9):
        err("Python 3.9+ is required!")
        err(f"You have Python {v.major}.{v.minor}. Please upgrade: https://python.org/downloads")
        sys.exit(1)
    ok(f"Python {v.major}.{v.minor} — OK")

# ─────────────────────────────────────────────────────────────
# STEP 2 — UPGRADE PIP
# ─────────────────────────────────────────────────────────────
def step_upgrade_pip():
    head("STEP 2 / 7  — Upgrading pip")
    sep()
    info("Upgrading pip...")
    success, out = run_pip("pip", upgrade=True)
    if success:
        ok("pip upgraded")
    else:
        warn("pip upgrade failed (non-critical, continuing)")
        dim(out[:200])

# ─────────────────────────────────────────────────────────────
# STEP 3 — DETECT GPU / CUDA
# ─────────────────────────────────────────────────────────────
def step_detect_gpu():
    head("STEP 3 / 7  — Detecting GPU / CUDA")
    sep()

    # Try to find NVIDIA driver via nvcc or nvidia-smi
    nvcc   = shutil.which("nvcc")
    nismi  = shutil.which("nvidia-smi")

    cuda_ver = None
    if nismi:
        try:
            r = subprocess.run([nismi, "--query-gpu=driver_version",
                                "--format=csv,noheader"],
                               capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                info(f"NVIDIA driver  : {r.stdout.strip()}")
        except Exception:
            pass

    if nvcc:
        try:
            r = subprocess.run([nvcc, "--version"], capture_output=True, text=True, timeout=5)
            for line in r.stdout.splitlines():
                if "release" in line.lower():
                    # e.g. "Cuda compilation tools, release 11.8, V11.8.89"
                    parts = line.split("release ")
                    if len(parts) > 1:
                        cuda_ver = parts[1].split(",")[0].strip()  # e.g. "11.8"
            if cuda_ver:
                info(f"CUDA version   : {cuda_ver}")
        except Exception:
            pass

    if cuda_ver:
        ok("NVIDIA GPU detected — will install PyTorch with CUDA")
    else:
        warn("No NVIDIA GPU detected — will install CPU-only PyTorch")
        warn("Analysis will be slower but fully functional")

    return cuda_ver

# ─────────────────────────────────────────────────────────────
# STEP 4 — INSTALL PYTORCH
# ─────────────────────────────────────────────────────────────
def step_install_torch(cuda_ver):
    head("STEP 4 / 7  — Installing PyTorch + TorchAudio")
    sep()

    # Check if already installed
    found, ver = check_import("torch")
    if found:
        ok(f"PyTorch already installed  (v{ver})")
        found2, ver2 = check_import("torchaudio")
        if found2:
            ok(f"TorchAudio already installed (v{ver2})")
            return
        else:
            warn("TorchAudio not found — installing...")

    # Build correct install command
    # Map CUDA version string → torch index URL
    cuda_index_map = {
        "12.4": "cu124",
        "12.3": "cu121",
        "12.2": "cu121",
        "12.1": "cu121",
        "12.0": "cu121",
        "11.8": "cu118",
        "11.7": "cu117",
        "11.6": "cu116",
    }

    if cuda_ver and cuda_ver in cuda_index_map:
        cuda_tag = cuda_index_map[cuda_ver]
    elif cuda_ver:
        # Try nearest known
        major = cuda_ver.split(".")[0]
        cuda_tag = "cu124" if major == "12" else "cu118"
    else:
        cuda_tag = None   # CPU only

    if cuda_tag:
        index_url = f"https://download.pytorch.org/whl/{cuda_tag}"
        info(f"PyTorch index  : {index_url}")
        info("Installing torch + torchaudio (GPU)... [this may take 5–15 min]")
        cmd = [sys.executable, "-m", "pip", "install",
               "torch", "torchaudio",
               "--index-url", index_url, "--quiet"]
    else:
        info("Installing torch + torchaudio (CPU)... [this may take 3–8 min]")
        cmd = [sys.executable, "-m", "pip", "install",
               "torch", "torchaudio", "--quiet"]

    result = subprocess.run(cmd, text=True)
    if result.returncode == 0:
        ok("PyTorch installed successfully")
    else:
        err("PyTorch install failed!")
        err("Try manually: pip install torch torchaudio")
        sys.exit(1)

# ─────────────────────────────────────────────────────────────
# STEP 5 — INSTALL WHISPERX + CORE DEPS
# ─────────────────────────────────────────────────────────────
def step_install_whisperx():
    head("STEP 5 / 7  — Installing WhisperX + dependencies")
    sep()

    packages = [
        ("whisperx",       "whisperx",        "WhisperX"),
        ("numpy",          "numpy",            "NumPy"),
        ("librosa",        "librosa",          "Librosa"),
        ("ctranslate2",    "ctranslate2",      "CTranslate2"),
        ("faster_whisper", "faster-whisper",   "Faster-Whisper"),
        ("pyannote.audio", "pyannote.audio",   "Pyannote.Audio"),
    ]

    for module, pkg, label in packages:
        found, ver = check_import(module)
        if found:
            ok(f"{label:<20} already installed  (v{ver})")
            continue

        info(f"Installing {label}...")
        success, log = run_pip(pkg)
        if success:
            found2, ver2 = check_import(module)
            if found2:
                ok(f"{label:<20} installed  (v{ver2})")
            else:
                ok(f"{label:<20} installed")
        else:
            if "whisperx" in pkg.lower():
                # Fallback: install from GitHub
                warn("PyPI install failed, trying GitHub source...")
                cmd = [sys.executable, "-m", "pip", "install",
                       "git+https://github.com/m-bain/whisperX.git", "--quiet"]
                r2 = subprocess.run(cmd, text=True)
                if r2.returncode == 0:
                    ok(f"{label:<20} installed from GitHub")
                else:
                    err(f"{label} install FAILED!")
                    err("Please run manually: pip install git+https://github.com/m-bain/whisperX.git")
            elif "pyannote" in pkg.lower():
                warn(f"{label} — optional (speaker diarization). Skipping.")
            else:
                err(f"{label} install FAILED — run manually: pip install {pkg}")

# ─────────────────────────────────────────────────────────────
# STEP 6 — CHECK FFMPEG
# ─────────────────────────────────────────────────────────────
def step_check_ffmpeg():
    head("STEP 6 / 7  — Checking FFmpeg")
    sep()

    if ffmpeg_found():
        try:
            r = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, timeout=5)
            ver_line = r.stdout.splitlines()[0] if r.stdout else "unknown"
            ok(f"FFmpeg found: {ver_line[:55]}")
        except Exception:
            ok("FFmpeg found in PATH")
        return

    err("FFmpeg NOT found in PATH!")
    print()

    if sys.platform == "win32":
        info("WINDOWS — How to install FFmpeg:")
        print()
        print(f"  {C_BOLD}Option A — winget (recommended):{C_RESET}")
        print(f"    {C_CYAN}winget install ffmpeg{C_RESET}")
        print()
        print(f"  {C_BOLD}Option B — Chocolatey:{C_RESET}")
        print(f"    {C_CYAN}choco install ffmpeg{C_RESET}")
        print()
        print(f"  {C_BOLD}Option C — Manual:{C_RESET}")
        print(f"    1. Download: {C_BLUE}https://www.gyan.dev/ffmpeg/builds/{C_RESET}")
        print(f"    2. Extract to  C:\\ffmpeg\\")
        print(f"    3. Add  C:\\ffmpeg\\bin  to System PATH")
        print(f"    4. Restart terminal")
        print()

        # Try winget automatically
        if shutil.which("winget"):
            ans = input(f"  {C_YELLOW}Try to install FFmpeg via winget now? [y/N]: {C_RESET}").strip().lower()
            if ans == "y":
                info("Running: winget install ffmpeg ...")
                r = subprocess.run(["winget", "install", "ffmpeg"], text=True)
                if r.returncode == 0 and ffmpeg_found():
                    ok("FFmpeg installed successfully via winget!")
                else:
                    warn("winget finished — please restart your terminal and re-run the app")

    elif sys.platform == "darwin":
        info("macOS — Install via Homebrew:")
        print(f"    {C_CYAN}brew install ffmpeg{C_RESET}")

    else:
        info("Linux — Install via package manager:")
        print(f"    Ubuntu/Debian : {C_CYAN}sudo apt install ffmpeg{C_RESET}")
        print(f"    Fedora        : {C_CYAN}sudo dnf install ffmpeg{C_RESET}")
        print(f"    Arch          : {C_CYAN}sudo pacman -S ffmpeg{C_RESET}")

        # Try apt automatically on Debian/Ubuntu
        if shutil.which("apt"):
            ans = input(f"\n  {C_YELLOW}Try to install FFmpeg via apt now? [y/N]: {C_RESET}").strip().lower()
            if ans == "y":
                info("Running: sudo apt install ffmpeg -y ...")
                r = subprocess.run(["sudo", "apt", "install", "ffmpeg", "-y"], text=True)
                if r.returncode == 0 and ffmpeg_found():
                    ok("FFmpeg installed successfully!")
                else:
                    warn("apt finished — check output above")

    print()
    warn("FFmpeg is REQUIRED for video file support.")
    warn("Audio-only files (.wav, .mp3, etc.) will still work without it.")

# ─────────────────────────────────────────────────────────────
# STEP 7 — FINAL CHECK
# ─────────────────────────────────────────────────────────────
def step_final_check():
    head("STEP 7 / 7  — Final verification")
    sep()

    all_good = True

    checks = [
        ("torch",     "PyTorch"),
        ("torchaudio","TorchAudio"),
        ("whisperx",  "WhisperX"),
        ("numpy",     "NumPy"),
        ("librosa",   "Librosa"),
    ]

    for module, label in checks:
        found, ver = check_import(module)
        if found:
            ok(f"{label:<20} v{ver}")
        else:
            err(f"{label:<20} MISSING!")
            all_good = False

    # Check CUDA
    print()
    if cuda_available():
        ok("CUDA (GPU) — available  🚀  Fast inference enabled")
    else:
        warn("CUDA not available — running on CPU (slower but works)")

    # Check FFmpeg
    if ffmpeg_found():
        ok("FFmpeg             — found in PATH")
    else:
        warn("FFmpeg             — NOT found (video input won't work)")

    print()
    if all_good:
        print(f"{C_BOLD}{C_GREEN}  ✔  ALL DEPENDENCIES INSTALLED SUCCESSFULLY!{C_RESET}")
        print(f"\n  {C_CYAN}Run the app:{C_RESET}")
        print(f"    {C_BOLD}python lipsync_v5.py{C_RESET}")
    else:
        print(f"{C_BOLD}{C_RED}  ✘  SOME PACKAGES ARE MISSING — check errors above{C_RESET}")
        print(f"\n  Try running the installer again or install missing packages manually.")

    return all_good


# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────
def main():
    print_banner()

    print(f"  {C_DIM}This installer will set up all dependencies for{C_RESET}")
    print(f"  {C_DIM}Auto LipSync v5.0 (WhisperX + phoneme alignment).{C_RESET}")
    print()
    print(f"  {C_YELLOW}Note: Download size may be 2–8 GB depending on GPU support.{C_RESET}")
    print(f"  {C_YELLOW}Make sure you have a stable internet connection.{C_RESET}")
    print()

    ans = input(f"  {C_CYAN}Start installation? [Y/n]: {C_RESET}").strip().lower()
    if ans == "n":
        print("  Cancelled.")
        sys.exit(0)

    t_start = time.time()

    step_check_python()
    step_upgrade_pip()
    cuda_ver = step_detect_gpu()
    step_install_torch(cuda_ver)
    step_install_whisperx()
    step_check_ffmpeg()
    all_ok = step_final_check()

    elapsed = time.time() - t_start
    print()
    print(f"{C_DIM}  Total time: {elapsed/60:.1f} minutes{C_RESET}")
    print()

    if sys.platform == "win32":
        input("  Press Enter to close...")

    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
